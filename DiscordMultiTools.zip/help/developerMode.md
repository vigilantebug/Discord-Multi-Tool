# Developer Mode

If the `Copy ID` menu doesn't show up when right clicking:  
 - Enable developer mode in discord
   Go to user **Settings** > **Appearance** in discord and enable **Developer mode**. 

   <img src="https://user-images.githubusercontent.com/3372598/58374693-fa3df400-7f31-11e9-9abd-ba17b9440326.png" width="100%"> 