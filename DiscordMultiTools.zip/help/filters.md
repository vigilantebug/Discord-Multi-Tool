# filters

You can filter only messages that has links or contain files 


## has link
- If you select this option, only messages with links are going to be deleted.

## has file
- If you select this option, only messages with files are going to be deleted.
  Images, videos are also files.


----
This feature uses the Discord search to find messages:
https://support.discord.com/hc/en-us/articles/115000468588-Using-Search