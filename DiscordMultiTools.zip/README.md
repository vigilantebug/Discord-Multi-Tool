# TBK Mass DM Tool

A tool coded in discord.py which messages every friend on a user's account.

## Installation

Run setup.bat to install dependencies or manually enter the following into the terminal:

```bash
pip install discord
pip install colorama
pip install requests
pip install datetime
pip install random
pip install init
pip install sys
pip install subprocess
pip install os
```

## Usage

```python
python tbk-mass-dm.py

# returns '~input@token>'
# paste your discord token 
```

## Showcase Video
[![YT Redirect](https://img.youtube.com/vi/Seo17CA0bC4/0.jpg)](https://www.youtube.com/watch?v=Seo17CA0bC4)

## Contributing
Developed and distributed by Nax

## License
[MIT](https://choosealicense.com/licenses/mit/)
